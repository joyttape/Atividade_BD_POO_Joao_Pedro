﻿namespace Form_CRUD_Fornecedor_JP.Forms
{
    partial class FormDeletar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            button1 = new Button();
            txtIdFornecedor = new TextBox();
            label9 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 13.7999992F, FontStyle.Bold);
            label1.ForeColor = Color.FromArgb(104, 140, 137);
            label1.Location = new Point(145, 103);
            label1.Name = "label1";
            label1.Size = new Size(320, 29);
            label1.TabIndex = 0;
            label1.Text = "Digite o Id do Fornecedor:";
            // 
            // button1
            // 
            button1.Font = new Font("Microsoft Sans Serif", 13.7999992F, FontStyle.Bold);
            button1.ForeColor = Color.FromArgb(104, 140, 137);
            button1.Location = new Point(657, 178);
            button1.Name = "button1";
            button1.Size = new Size(126, 43);
            button1.TabIndex = 1;
            button1.Text = "Deletar";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // txtIdFornecedor
            // 
            txtIdFornecedor.Font = new Font("Microsoft Sans Serif", 13.7999992F, FontStyle.Bold);
            txtIdFornecedor.Location = new Point(471, 98);
            txtIdFornecedor.Name = "txtIdFornecedor";
            txtIdFornecedor.Size = new Size(170, 34);
            txtIdFornecedor.TabIndex = 2;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = SystemColors.Control;
            label9.Font = new Font("Microsoft Sans Serif", 13.7999992F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.FromArgb(104, 140, 137);
            label9.Location = new Point(245, 43);
            label9.Name = "label9";
            label9.Size = new Size(318, 29);
            label9.TabIndex = 18;
            label9.Text = "DELETAR FORNECEDOR";
            // 
            // FormDeletar
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(795, 233);
            Controls.Add(label9);
            Controls.Add(txtIdFornecedor);
            Controls.Add(button1);
            Controls.Add(label1);
            Name = "FormDeletar";
            Text = "FormDeletar";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button button1;
        private TextBox txtIdFornecedor;
        private Label label9;
    }
}