﻿namespace Form_CRUD_Fornecedor_JP.Forms
{
    partial class FormAdicionar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtNome = new TextBox();
            txtRazaoSocial = new TextBox();
            label2 = new Label();
            txtAtivo = new TextBox();
            label3 = new Label();
            txtCNPJ = new TextBox();
            label4 = new Label();
            txtTelefone = new TextBox();
            label5 = new Label();
            txtEmail = new TextBox();
            label6 = new Label();
            txtAtvEco = new TextBox();
            label7 = new Label();
            btSalvar = new Button();
            btNovo = new Button();
            label8 = new Label();
            label9 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.Control;
            label1.Font = new Font("Montserrat SemiBold", 13.7999992F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(104, 140, 137);
            label1.Location = new Point(32, 118);
            label1.Name = "label1";
            label1.Size = new Size(93, 38);
            label1.TabIndex = 0;
            label1.Text = "Nome:";
            // 
            // txtNome
            // 
            txtNome.Font = new Font("Montserrat", 12F);
            txtNome.Location = new Point(120, 123);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(301, 32);
            txtNome.TabIndex = 1;
            // 
            // txtRazaoSocial
            // 
            txtRazaoSocial.Font = new Font("Montserrat", 12F);
            txtRazaoSocial.Location = new Point(595, 121);
            txtRazaoSocial.Name = "txtRazaoSocial";
            txtRazaoSocial.Size = new Size(313, 32);
            txtRazaoSocial.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Montserrat SemiBold", 13.7999992F, FontStyle.Bold);
            label2.ForeColor = Color.FromArgb(104, 140, 137);
            label2.Location = new Point(427, 118);
            label2.Name = "label2";
            label2.Size = new Size(171, 38);
            label2.TabIndex = 2;
            label2.Text = "Razão Social:";
            // 
            // txtAtivo
            // 
            txtAtivo.Font = new Font("Montserrat", 12F);
            txtAtivo.Location = new Point(693, 252);
            txtAtivo.Name = "txtAtivo";
            txtAtivo.Size = new Size(170, 32);
            txtAtivo.TabIndex = 7;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Montserrat SemiBold", 13.7999992F, FontStyle.Bold);
            label3.ForeColor = Color.FromArgb(104, 140, 137);
            label3.Location = new Point(604, 249);
            label3.Name = "label3";
            label3.Size = new Size(83, 38);
            label3.TabIndex = 6;
            label3.Text = "Ativo:";
            // 
            // txtCNPJ
            // 
            txtCNPJ.Font = new Font("Montserrat", 12F);
            txtCNPJ.Location = new Point(110, 184);
            txtCNPJ.Name = "txtCNPJ";
            txtCNPJ.Size = new Size(311, 32);
            txtCNPJ.TabIndex = 5;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Montserrat SemiBold", 13.7999992F, FontStyle.Bold);
            label4.ForeColor = Color.FromArgb(104, 140, 137);
            label4.Location = new Point(32, 182);
            label4.Name = "label4";
            label4.Size = new Size(83, 38);
            label4.TabIndex = 4;
            label4.Text = "CNPJ:";
            // 
            // txtTelefone
            // 
            txtTelefone.Font = new Font("Montserrat", 12F);
            txtTelefone.Location = new Point(160, 317);
            txtTelefone.Name = "txtTelefone";
            txtTelefone.Size = new Size(272, 32);
            txtTelefone.TabIndex = 13;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Montserrat SemiBold", 13.7999992F, FontStyle.Bold);
            label5.ForeColor = Color.FromArgb(104, 140, 137);
            label5.Location = new Point(32, 315);
            label5.Name = "label5";
            label5.Size = new Size(122, 38);
            label5.TabIndex = 12;
            label5.Text = "Telefone:";
            // 
            // txtEmail
            // 
            txtEmail.Font = new Font("Montserrat", 12F);
            txtEmail.Location = new Point(531, 184);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(377, 32);
            txtEmail.TabIndex = 11;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Montserrat SemiBold", 13.7999992F, FontStyle.Bold);
            label6.ForeColor = Color.FromArgb(104, 140, 137);
            label6.Location = new Point(427, 182);
            label6.Name = "label6";
            label6.Size = new Size(98, 38);
            label6.TabIndex = 10;
            label6.Text = "E-mail:";
            // 
            // txtAtvEco
            // 
            txtAtvEco.Font = new Font("Montserrat", 12F);
            txtAtvEco.Location = new Point(309, 252);
            txtAtvEco.Name = "txtAtvEco";
            txtAtvEco.Size = new Size(289, 32);
            txtAtvEco.TabIndex = 9;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Montserrat SemiBold", 13.7999992F, FontStyle.Bold);
            label7.ForeColor = Color.FromArgb(104, 140, 137);
            label7.Location = new Point(32, 247);
            label7.Name = "label7";
            label7.Size = new Size(271, 38);
            label7.TabIndex = 8;
            label7.Text = "Atividade Econômica:";
            // 
            // btSalvar
            // 
            btSalvar.Font = new Font("Montserrat SemiBold", 13.7999992F, FontStyle.Bold);
            btSalvar.ForeColor = Color.FromArgb(104, 140, 137);
            btSalvar.Location = new Point(751, 381);
            btSalvar.Name = "btSalvar";
            btSalvar.Size = new Size(157, 43);
            btSalvar.TabIndex = 14;
            btSalvar.Text = "SALVAR";
            btSalvar.UseVisualStyleBackColor = true;
            btSalvar.Click += btSalvar_Click;
            // 
            // btNovo
            // 
            btNovo.Font = new Font("Montserrat SemiBold", 13.7999992F, FontStyle.Bold);
            btNovo.ForeColor = Color.FromArgb(104, 140, 137);
            btNovo.Location = new Point(751, 430);
            btNovo.Name = "btNovo";
            btNovo.Size = new Size(157, 43);
            btNovo.TabIndex = 15;
            btNovo.Text = "NOVO";
            btNovo.UseVisualStyleBackColor = true;
            btNovo.Click += btNovo_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Montserrat SemiBold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.FromArgb(104, 140, 137);
            label8.Location = new Point(767, 297);
            label8.Name = "label8";
            label8.Size = new Size(96, 56);
            label8.TabIndex = 16;
            label8.Text = "1 - Ativo\r\n0 - Inativo";
            label8.TextAlign = ContentAlignment.MiddleRight;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = SystemColors.Control;
            label9.Font = new Font("Montserrat SemiBold", 13.7999992F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.FromArgb(104, 140, 137);
            label9.Location = new Point(297, 59);
            label9.Name = "label9";
            label9.Size = new Size(323, 38);
            label9.TabIndex = 17;
            label9.Text = "CADASTRO FORNECEDOR";
            // 
            // FormAdicionar
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(934, 493);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(btNovo);
            Controls.Add(btSalvar);
            Controls.Add(txtTelefone);
            Controls.Add(label5);
            Controls.Add(txtEmail);
            Controls.Add(label6);
            Controls.Add(txtAtvEco);
            Controls.Add(label7);
            Controls.Add(txtAtivo);
            Controls.Add(label3);
            Controls.Add(txtCNPJ);
            Controls.Add(label4);
            Controls.Add(txtRazaoSocial);
            Controls.Add(label2);
            Controls.Add(txtNome);
            Controls.Add(label1);
            Name = "FormAdicionar";
            Text = "FormAdicionar";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtNome;
        private TextBox txtRazaoSocial;
        private Label label2;
        private TextBox txtAtivo;
        private Label label3;
        private TextBox txtCNPJ;
        private Label label4;
        private TextBox txtTelefone;
        private Label label5;
        private TextBox txtEmail;
        private Label label6;
        private TextBox txtAtvEco;
        private Label label7;
        private Button btSalvar;
        private Button btNovo;
        private Label label8;
        private Label label9;
    }
}