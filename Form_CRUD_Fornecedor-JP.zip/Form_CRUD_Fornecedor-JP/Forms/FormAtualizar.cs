﻿using Form_CRUD_Fornecedor_JP.DAO;
using Form_CRUD_Fornecedor_JP.Modelos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form_CRUD_Fornecedor_JP.Forms
{
    public partial class FormAtualizar : Form
    {
        private int idFornAt;
        public FormAtualizar()
        {
            InitializeComponent();
        }

        public FormAtualizar(int Id)
        {
            idFornAt = Id;
            InitializeComponent();

            Fornecedor forn1 = new Fornecedor();
            FornecedorDAO fdao = new FornecedorDAO();
            List<Fornecedor> lista = fdao.List();

            foreach (Fornecedor forn in lista)
            {
                if (forn.Id == idFornAt)
                {

                    txtIdFornecedor.Text = forn.Id.ToString();
                    txtNome.Text = forn.Nome;
                    txtCNPJ.Text = forn.CNPJ;
                    txtAtvEco.Text = forn.AtividadeEconomica;
                    txtAtivo.Text = forn.Ativo.ToString();
                    txtEmail.Text = forn.Email;
                    txtTelefone.Text = forn.Telefone;
                    txtRazaoSocial.Text = forn.RazaoSocial;

                    txtIdFornecedor.ReadOnly = true;
                }

            }
        }

        private void btPesquisar_Click(object sender, EventArgs e)
        {
            // não existe mais este botão
            try
            {
                Fornecedor forn1 = new Fornecedor();
                FornecedorDAO fdao = new FornecedorDAO();



                List<Fornecedor> lista = fdao.List();

                if (txtIdFornecedor.Text == "")
                {
                    MessageBox.Show("Não é possível continuar, id não inserido!", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    forn1.Id = Convert.ToInt32(txtIdFornecedor.Text);

                    foreach (Fornecedor forn in lista)
                    {
                        if (forn.Id == forn1.Id)
                        {
                            txtNome.Text = forn.Nome;
                            txtCNPJ.Text = forn.CNPJ;
                            txtAtvEco.Text = forn.AtividadeEconomica;
                            txtAtivo.Text = forn.Ativo.ToString();
                            txtEmail.Text = forn.Email;
                            txtTelefone.Text = forn.Telefone;
                            txtRazaoSocial.Text = forn.RazaoSocial;
                        }
                    }

                }
            }
            catch
            {
                MessageBox.Show("Usuário não existe", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btSalvar_Click(object sender, EventArgs e)
        {
            Fornecedor forn1 = new Fornecedor();
            FornecedorDAO fdao = new FornecedorDAO();

            forn1.Id = idFornAt;

            forn1.Nome = Convert.ToString(txtNome.Text);
            forn1.RazaoSocial = Convert.ToString(txtRazaoSocial.Text);
            forn1.CNPJ = Convert.ToString(txtCNPJ.Text);
            forn1.Ativo = Convert.ToInt32(txtAtivo.Text);
            forn1.AtividadeEconomica = Convert.ToString(txtAtvEco.Text);
            forn1.Telefone = Convert.ToString(txtTelefone.Text);
            forn1.Email = Convert.ToString(txtEmail.Text);


            fdao.Update(forn1);
            Close();


        }

        private void FormAtualizar_Load(object sender, EventArgs e)
        {

        }
    }
}
