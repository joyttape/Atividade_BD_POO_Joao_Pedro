﻿using Form_CRUD_Fornecedor_JP.DAO;
using Form_CRUD_Fornecedor_JP.Modelos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form_CRUD_Fornecedor_JP.Forms
{
    public partial class FormAdicionar : Form
    {
        public FormAdicionar()
        {
            InitializeComponent();
        }

        private void btSalvar_Click(object sender, EventArgs e)
        {
            Fornecedor forn1 = new Fornecedor();
            FornecedorDAO fdao = new FornecedorDAO();

            if (txtAtivo.Text == "" || txtAtvEco.Text == "" || txtCNPJ.Text == "" || txtEmail.Text == "" || txtNome.Text == "" || txtRazaoSocial.Text == "" ||
               txtTelefone.Text == "")
            {
                MessageBox.Show("Há um campo de texto em branco!", "Cadastro", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                forn1.Nome = Convert.ToString(txtNome.Text);
                forn1.RazaoSocial = Convert.ToString(txtRazaoSocial.Text);
                forn1.CNPJ = Convert.ToString(txtCNPJ.Text);
                forn1.Ativo = Convert.ToInt32(txtAtivo.Text);
                forn1.AtividadeEconomica = Convert.ToString(txtAtvEco.Text);
                forn1.Telefone = Convert.ToString(txtTelefone.Text);
                forn1.Email = Convert.ToString(txtEmail.Text);

                fdao.Insert(forn1);

                
            }
        }

        private void btNovo_Click(object sender, EventArgs e)
        {
            txtAtivo.Clear();
            txtTelefone.Clear();
            txtAtivo.Clear();
            txtCNPJ.Clear();
            txtEmail.Clear();
            txtAtvEco.Clear();
            txtNome.Clear();
            txtRazaoSocial.Clear();
        }
    }
}
