﻿namespace Form_CRUD_Fornecedor_JP.Forms
{
    partial class FormAtualizar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btSalvar = new Button();
            txtTelefone = new TextBox();
            label5 = new Label();
            txtEmail = new TextBox();
            label6 = new Label();
            txtAtvEco = new TextBox();
            label7 = new Label();
            txtAtivo = new TextBox();
            label3 = new Label();
            txtCNPJ = new TextBox();
            label4 = new Label();
            txtRazaoSocial = new TextBox();
            label2 = new Label();
            txtNome = new TextBox();
            label1 = new Label();
            txtIdFornecedor = new TextBox();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            SuspendLayout();
            // 
            // btSalvar
            // 
            btSalvar.Font = new Font("Microsoft Sans Serif", 13.7999992F, FontStyle.Bold);
            btSalvar.ForeColor = Color.FromArgb(104, 140, 137);
            btSalvar.Location = new Point(759, 351);
            btSalvar.Name = "btSalvar";
            btSalvar.Size = new Size(157, 43);
            btSalvar.TabIndex = 29;
            btSalvar.Text = "SALVAR";
            btSalvar.UseVisualStyleBackColor = true;
            btSalvar.Click += btSalvar_Click;
            // 
            // txtTelefone
            // 
            txtTelefone.Font = new Font("Montserrat", 12F);
            txtTelefone.Location = new Point(597, 297);
            txtTelefone.Name = "txtTelefone";
            txtTelefone.Size = new Size(251, 32);
            txtTelefone.TabIndex = 28;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft Sans Serif", 13.7999992F, FontStyle.Bold);
            label5.ForeColor = Color.FromArgb(104, 140, 137);
            label5.Location = new Point(469, 297);
            label5.Name = "label5";
            label5.Size = new Size(125, 29);
            label5.TabIndex = 27;
            label5.Text = "Telefone:";
            // 
            // txtEmail
            // 
            txtEmail.Font = new Font("Montserrat", 12F);
            txtEmail.Location = new Point(121, 297);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(342, 32);
            txtEmail.TabIndex = 26;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Microsoft Sans Serif", 13.7999992F, FontStyle.Bold);
            label6.ForeColor = Color.FromArgb(104, 140, 137);
            label6.Location = new Point(28, 297);
            label6.Name = "label6";
            label6.Size = new Size(95, 29);
            label6.TabIndex = 25;
            label6.Text = "E-mail:";
            // 
            // txtAtvEco
            // 
            txtAtvEco.Font = new Font("Montserrat", 12F);
            txtAtvEco.Location = new Point(289, 247);
            txtAtvEco.Name = "txtAtvEco";
            txtAtvEco.Size = new Size(260, 32);
            txtAtvEco.TabIndex = 24;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft Sans Serif", 13.7999992F, FontStyle.Bold);
            label7.ForeColor = Color.FromArgb(104, 140, 137);
            label7.Location = new Point(28, 250);
            label7.Name = "label7";
            label7.Size = new Size(264, 29);
            label7.TabIndex = 23;
            label7.Text = "Atividade Econômica:";
            // 
            // txtAtivo
            // 
            txtAtivo.Font = new Font("Montserrat", 12F);
            txtAtivo.Location = new Point(546, 197);
            txtAtivo.Name = "txtAtivo";
            txtAtivo.Size = new Size(166, 32);
            txtAtivo.TabIndex = 22;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 13.7999992F, FontStyle.Bold);
            label3.ForeColor = Color.FromArgb(104, 140, 137);
            label3.Location = new Point(463, 197);
            label3.Name = "label3";
            label3.Size = new Size(77, 29);
            label3.TabIndex = 21;
            label3.Text = "Ativo:";
            // 
            // txtCNPJ
            // 
            txtCNPJ.Font = new Font("Montserrat", 12F);
            txtCNPJ.Location = new Point(115, 192);
            txtCNPJ.Name = "txtCNPJ";
            txtCNPJ.Size = new Size(342, 32);
            txtCNPJ.TabIndex = 20;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 13.7999992F, FontStyle.Bold);
            label4.ForeColor = Color.FromArgb(104, 140, 137);
            label4.Location = new Point(28, 197);
            label4.Name = "label4";
            label4.Size = new Size(87, 29);
            label4.TabIndex = 19;
            label4.Text = "CNPJ:";
            // 
            // txtRazaoSocial
            // 
            txtRazaoSocial.Font = new Font("Montserrat", 12F);
            txtRazaoSocial.Location = new Point(607, 146);
            txtRazaoSocial.Name = "txtRazaoSocial";
            txtRazaoSocial.Size = new Size(309, 32);
            txtRazaoSocial.TabIndex = 18;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Sans Serif", 13.7999992F, FontStyle.Bold);
            label2.ForeColor = Color.FromArgb(104, 140, 137);
            label2.Location = new Point(430, 146);
            label2.Name = "label2";
            label2.Size = new Size(173, 29);
            label2.TabIndex = 17;
            label2.Text = "Razão Social:";
            // 
            // txtNome
            // 
            txtNome.Font = new Font("Montserrat", 12F);
            txtNome.Location = new Point(121, 146);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(303, 32);
            txtNome.TabIndex = 16;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 13.7999992F, FontStyle.Bold);
            label1.ForeColor = Color.FromArgb(104, 140, 137);
            label1.Location = new Point(28, 144);
            label1.Name = "label1";
            label1.Size = new Size(90, 29);
            label1.TabIndex = 15;
            label1.Text = "Nome:";
            // 
            // txtIdFornecedor
            // 
            txtIdFornecedor.Font = new Font("Montserrat", 12F);
            txtIdFornecedor.Location = new Point(508, 79);
            txtIdFornecedor.Name = "txtIdFornecedor";
            txtIdFornecedor.Size = new Size(166, 32);
            txtIdFornecedor.TabIndex = 31;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Microsoft Sans Serif", 13.7999992F, FontStyle.Bold);
            label8.ForeColor = Color.FromArgb(104, 140, 137);
            label8.Location = new Point(289, 79);
            label8.Name = "label8";
            label8.Size = new Size(213, 29);
            label8.TabIndex = 30;
            label8.Text = "Id do fornecedor:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = SystemColors.Control;
            label9.Font = new Font("Microsoft Sans Serif", 13.7999992F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.FromArgb(104, 140, 137);
            label9.Location = new Point(346, 20);
            label9.Name = "label9";
            label9.Size = new Size(246, 29);
            label9.TabIndex = 33;
            label9.Text = "ATUALIZAR DADOS";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.FromArgb(104, 140, 137);
            label10.Location = new Point(718, 197);
            label10.Name = "label10";
            label10.Size = new Size(93, 40);
            label10.TabIndex = 34;
            label10.Text = "1 - Ativo\r\n0 - Inativo";
            label10.TextAlign = ContentAlignment.MiddleRight;
            // 
            // FormAtualizar
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(928, 406);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(txtIdFornecedor);
            Controls.Add(label8);
            Controls.Add(btSalvar);
            Controls.Add(txtTelefone);
            Controls.Add(label5);
            Controls.Add(txtEmail);
            Controls.Add(label6);
            Controls.Add(txtAtvEco);
            Controls.Add(label7);
            Controls.Add(txtAtivo);
            Controls.Add(label3);
            Controls.Add(txtCNPJ);
            Controls.Add(label4);
            Controls.Add(txtRazaoSocial);
            Controls.Add(label2);
            Controls.Add(txtNome);
            Controls.Add(label1);
            Name = "FormAtualizar";
            Text = "FormAtualizar";
            Load += FormAtualizar_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btSalvar;
        private TextBox txtTelefone;
        private Label label5;
        private TextBox txtEmail;
        private Label label6;
        private TextBox txtAtvEco;
        private Label label7;
        private TextBox txtAtivo;
        private Label label3;
        private TextBox txtCNPJ;
        private Label label4;
        private TextBox txtRazaoSocial;
        private Label label2;
        private TextBox txtNome;
        private Label label1;
        private TextBox txtIdFornecedor;
        private Label label8;
        private Label label9;
        private Label label10;
    }
}