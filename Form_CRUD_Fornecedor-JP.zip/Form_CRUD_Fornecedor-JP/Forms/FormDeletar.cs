﻿using Form_CRUD_Fornecedor_JP.DAO;
using Form_CRUD_Fornecedor_JP.Modelos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form_CRUD_Fornecedor_JP.Forms
{
    public partial class FormDeletar : Form
    {
        public FormDeletar()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Fornecedor forn1 = new Fornecedor();
            FornecedorDAO fdao = new FornecedorDAO();

            forn1.Id = Convert.ToInt32(txtIdFornecedor.Text);

            fdao.Delete(forn1);

            txtIdFornecedor.Clear();
            

            
        }
    }
}
