﻿namespace Form_CRUD_Fornecedor_JP
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvForn = new DataGridView();
            IdForn = new DataGridViewTextBoxColumn();
            Nome = new DataGridViewTextBoxColumn();
            RazaoSocial = new DataGridViewTextBoxColumn();
            CNPJ = new DataGridViewTextBoxColumn();
            Ativo = new DataGridViewTextBoxColumn();
            AtvEco = new DataGridViewTextBoxColumn();
            Telefone = new DataGridViewTextBoxColumn();
            Email = new DataGridViewTextBoxColumn();
            btAdicionar = new Button();
            button1 = new Button();
            btDeletar = new Button();
            label1 = new Label();
            label2 = new Label();
            button3 = new Button();
            label3 = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvForn).BeginInit();
            SuspendLayout();
            // 
            // dgvForn
            // 
            dgvForn.AllowUserToAddRows = false;
            dgvForn.AllowUserToDeleteRows = false;
            dgvForn.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvForn.Columns.AddRange(new DataGridViewColumn[] { IdForn, Nome, RazaoSocial, CNPJ, Ativo, AtvEco, Telefone, Email });
            dgvForn.Location = new Point(8, 219);
            dgvForn.Name = "dgvForn";
            dgvForn.ReadOnly = true;
            dgvForn.RowHeadersWidth = 51;
            dgvForn.Size = new Size(1009, 301);
            dgvForn.TabIndex = 0;
            dgvForn.CellClick += dgvForn_CellClick;
            // 
            // IdForn
            // 
            IdForn.HeaderText = "Id Fornecedor";
            IdForn.MinimumWidth = 6;
            IdForn.Name = "IdForn";
            IdForn.ReadOnly = true;
            IdForn.Width = 125;
            // 
            // Nome
            // 
            Nome.HeaderText = "Nome";
            Nome.MinimumWidth = 6;
            Nome.Name = "Nome";
            Nome.ReadOnly = true;
            Nome.Width = 125;
            // 
            // RazaoSocial
            // 
            RazaoSocial.HeaderText = "Razão Social";
            RazaoSocial.MinimumWidth = 6;
            RazaoSocial.Name = "RazaoSocial";
            RazaoSocial.ReadOnly = true;
            RazaoSocial.Width = 125;
            // 
            // CNPJ
            // 
            CNPJ.HeaderText = "CNPJ";
            CNPJ.MinimumWidth = 6;
            CNPJ.Name = "CNPJ";
            CNPJ.ReadOnly = true;
            CNPJ.Width = 125;
            // 
            // Ativo
            // 
            Ativo.HeaderText = "Ativo";
            Ativo.MinimumWidth = 6;
            Ativo.Name = "Ativo";
            Ativo.ReadOnly = true;
            Ativo.Width = 125;
            // 
            // AtvEco
            // 
            AtvEco.HeaderText = "Atividade Econômica";
            AtvEco.MinimumWidth = 6;
            AtvEco.Name = "AtvEco";
            AtvEco.ReadOnly = true;
            AtvEco.Width = 125;
            // 
            // Telefone
            // 
            Telefone.HeaderText = "Telefone";
            Telefone.MinimumWidth = 6;
            Telefone.Name = "Telefone";
            Telefone.ReadOnly = true;
            Telefone.Width = 125;
            // 
            // Email
            // 
            Email.HeaderText = "Email";
            Email.MinimumWidth = 6;
            Email.Name = "Email";
            Email.ReadOnly = true;
            Email.Width = 125;
            // 
            // btAdicionar
            // 
            btAdicionar.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btAdicionar.ForeColor = Color.FromArgb(104, 140, 137);
            btAdicionar.Location = new Point(8, 172);
            btAdicionar.Name = "btAdicionar";
            btAdicionar.Size = new Size(129, 41);
            btAdicionar.TabIndex = 1;
            btAdicionar.Text = "Adicionar";
            btAdicionar.UseVisualStyleBackColor = true;
            btAdicionar.Click += btAdicionar_Click;
            // 
            // button1
            // 
            button1.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold);
            button1.ForeColor = Color.FromArgb(104, 140, 137);
            button1.Location = new Point(862, 172);
            button1.Name = "button1";
            button1.Size = new Size(153, 38);
            button1.TabIndex = 3;
            button1.Text = "Limpar Lista";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // btDeletar
            // 
            btDeletar.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold);
            btDeletar.ForeColor = Color.FromArgb(104, 140, 137);
            btDeletar.Location = new Point(143, 169);
            btDeletar.Name = "btDeletar";
            btDeletar.Size = new Size(125, 41);
            btDeletar.TabIndex = 4;
            btDeletar.Text = "Deletar";
            btDeletar.UseVisualStyleBackColor = true;
            btDeletar.Click += btDeletar_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(104, 140, 137);
            label1.Location = new Point(374, 9);
            label1.Name = "label1";
            label1.Size = new Size(279, 32);
            label1.TabIndex = 6;
            label1.Text = "CRUD - Fornecedor";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.FromArgb(104, 140, 137);
            label2.Location = new Point(321, 41);
            label2.Name = "label2";
            label2.Size = new Size(405, 25);
            label2.TabIndex = 7;
            label2.Text = "João Pedro Gundim Guimarães ADS 3°P";
            // 
            // button3
            // 
            button3.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold);
            button3.ForeColor = Color.FromArgb(104, 140, 137);
            button3.Location = new Point(864, 128);
            button3.Name = "button3";
            button3.Size = new Size(153, 38);
            button3.TabIndex = 8;
            button3.Text = "Listar";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold);
            label3.ForeColor = Color.FromArgb(104, 140, 137);
            label3.Location = new Point(353, 191);
            label3.Name = "label3";
            label3.Size = new Size(367, 25);
            label3.TabIndex = 9;
            label3.Text = "Para editar clique na célula desejada";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1029, 535);
            Controls.Add(label3);
            Controls.Add(button3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btDeletar);
            Controls.Add(button1);
            Controls.Add(btAdicionar);
            Controls.Add(dgvForn);
            Name = "Form1";
            Text = "Form CRUD";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dgvForn).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgvForn;
        private Button btAdicionar;
        private Button button1;
        private Button btDeletar;
        private Label label1;
        private Label label2;
        private Button button3;
        private DataGridViewTextBoxColumn IdForn;
        private DataGridViewTextBoxColumn Nome;
        private DataGridViewTextBoxColumn RazaoSocial;
        private DataGridViewTextBoxColumn CNPJ;
        private DataGridViewTextBoxColumn Ativo;
        private DataGridViewTextBoxColumn AtvEco;
        private DataGridViewTextBoxColumn Telefone;
        private DataGridViewTextBoxColumn Email;
        private Label label3;
    }
}
