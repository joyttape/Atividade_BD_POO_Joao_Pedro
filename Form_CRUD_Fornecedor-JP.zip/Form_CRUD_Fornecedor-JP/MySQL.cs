﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Form_CRUD_Fornecedor_JP
{
    public static class Conexao
    {
        static MySqlConnection conexao;

        public static MySqlConnection Conectar()
        {
            try
            {
                string strconexao = "server=localhost;port= 3306;uid=root;pwd=Jpgundim0503-;database=Fornecedor_BD_POO";
                conexao = new MySqlConnection(strconexao);
                conexao.Open();

                
            }
            catch (Exception ex)
            {
                throw new Exception($"Erro ao conectar! {ex.Message}");
            }
            return conexao;
        }

        public static void FecharConexao()
        {
            conexao.Close();
        }
    }
}
