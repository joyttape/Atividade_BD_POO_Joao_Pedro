﻿using Form_CRUD_Fornecedor_JP.Modelos;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Form_CRUD_Fornecedor_JP.DAO
{
    internal class FornecedorDAO
    {
        public void Insert(Fornecedor fornecedores)
        {
            try
            {
                string sql = "INSERT INTO Fornecedores(Nome,RazaoSocial,CNPJ,Ativo,AtividadeEconomica,Telefone,Email)"
                    + "VALUES(@nome,@razaosocial,@cnpj,@ativo,@atividadeeconomica,@telefone,@email)";

                MySqlCommand comando = new MySqlCommand(sql, Conexao.Conectar());
                
                comando.Parameters.AddWithValue("@nome", fornecedores.Nome);
                comando.Parameters.AddWithValue("@razaosocial", fornecedores.RazaoSocial);
                comando.Parameters.AddWithValue("@cnpj", fornecedores.CNPJ);
                comando.Parameters.AddWithValue("@ativo", fornecedores.Ativo);
                comando.Parameters.AddWithValue("@atividadeeconomica", fornecedores.AtividadeEconomica);
                comando.Parameters.AddWithValue("@telefone", fornecedores.Telefone);
                comando.Parameters.AddWithValue("@email", fornecedores.Email);

                comando.ExecuteNonQuery();
                MessageBox.Show("Cadastro Concluído!", "Cadastro", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}", "Cadastro", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            finally
            {
                Conexao.FecharConexao();
            }
        }

        public void Delete(Fornecedor fornecedores)
        {
            try
            {
                string sql = "DELETE FROM Fornecedores WHERE Id_Fornecedor = @IdFornecedor";
                MySqlCommand comando = new MySqlCommand(sql, Conexao.Conectar());

                comando.Parameters.AddWithValue("@IdFornecedor", fornecedores.Id);
                comando.ExecuteNonQuery();
                
                if (comando.ExecuteNonQuery() > 0)
                {
                    MessageBox.Show("Usuário Deletado!", "Deletar", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    
                }
                else
                {
                    MessageBox.Show("Este usuário já foi deletado!", "Deletar", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}", "Apagar", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            finally
            {
                Conexao.FecharConexao();
            }
        }

        public List<Fornecedor> List()
        {
            List<Fornecedor> fornecedores = new List<Fornecedor>();

            try
            {
                var sql = "SELECT * FROM Fornecedores ORDER BY Id_Fornecedor ASC;";
                MySqlCommand comando = new MySqlCommand(sql, Conexao.Conectar());
                using (MySqlDataReader dr = comando.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        Fornecedor forne = new Fornecedor();
                        forne.Id = dr.GetInt32("Id_Fornecedor");
                        forne.Nome = dr.GetString("Nome");
                        forne.RazaoSocial = dr.GetString("RazaoSocial");
                        forne.CNPJ = dr.GetString("CNPJ");
                        forne.Ativo = dr.GetInt32("Ativo");
                        forne.AtividadeEconomica = dr.GetString("AtividadeEconomica");
                        forne.Telefone = dr.GetString("Telefone");
                        forne.Email = dr.GetString("Email");

                        fornecedores.Add(forne);
                    }
                }
                Conexao.FecharConexao();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}", "Listar", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

            return fornecedores;

        }

        public void Update(Fornecedor fornecedores)
        {

            try
            {
                string sql = "UPDATE Fornecedores SET Nome = @nome, RazaoSocial = @razaosocial, CNPJ = @cnpj, Ativo = @ativo, AtividadeEconomica = @atividadeeconomica," +
                    "Telefone = @telefone, Email = @email WHERE Id_Fornecedor = @IdFornecedor";

                MySqlCommand comando = new MySqlCommand(sql, Conexao.Conectar());

                comando.Parameters.AddWithValue("@nome", fornecedores.Nome);
                comando.Parameters.AddWithValue("@razaosocial", fornecedores.RazaoSocial);
                comando.Parameters.AddWithValue("@cnpj", fornecedores.CNPJ);
                comando.Parameters.AddWithValue("@ativo", fornecedores.Ativo);
                comando.Parameters.AddWithValue("@atividadeeconomica", fornecedores.AtividadeEconomica);
                comando.Parameters.AddWithValue("@telefone", fornecedores.Telefone);
                comando.Parameters.AddWithValue("@email", fornecedores.Email);
                comando.Parameters.AddWithValue("@IdFornecedor", fornecedores.Id);
                comando.ExecuteNonQuery();
                MessageBox.Show("Dados atualizados!", "Atualizar", MessageBoxButtons.OK, MessageBoxIcon.Information);

                Conexao.FecharConexao();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}", "Atualizar", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                throw;
            }
        }
    }
}
