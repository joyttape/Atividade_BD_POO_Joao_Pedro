using Form_CRUD_Fornecedor_JP.DAO;
using Form_CRUD_Fornecedor_JP.Forms;
using Form_CRUD_Fornecedor_JP.Modelos;

namespace Form_CRUD_Fornecedor_JP
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Fornecedor forn1 = new Fornecedor();
            FornecedorDAO fdao = new FornecedorDAO();

            List<Fornecedor> lista = fdao.List();

            foreach (var forn in lista)
            {
                dgvForn.Rows.Add(forn.Id, forn.Nome, forn.RazaoSocial, forn.CNPJ, forn.Ativo, forn.AtividadeEconomica, forn.Telefone, forn.Email);
            }

        }

        private void btAdicionar_Click(object sender, EventArgs e)
        {
            FormAdicionar form = new FormAdicionar();
            form.ShowDialog();
        }

        private void btListar_Click(object sender, EventArgs e)
        {
            
            Fornecedor forn1 = new Fornecedor();
            FornecedorDAO fdao = new FornecedorDAO();

            List<Fornecedor> lista = fdao.List();

            foreach (var forn in lista)
            {
                dgvForn.Rows.Add(forn.Id, forn.Nome, forn.RazaoSocial, forn.CNPJ, forn.Ativo, forn.AtividadeEconomica, forn.Telefone, forn.Email);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dgvForn.Rows.Clear();
        }

        private void btDeletar_Click(object sender, EventArgs e)
        {
            FormDeletar form = new FormDeletar();
            form.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //este bot�o n�o existe mais
            FormAtualizar form = new FormAtualizar();
            form.ShowDialog();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void dgvForn_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int id = Convert.ToInt32(dgvForn.Rows[e.RowIndex].Cells["IdForn"].Value);

            FormAtualizar form = new FormAtualizar(id);
            form.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Fornecedor forn1 = new Fornecedor();
            FornecedorDAO fdao = new FornecedorDAO();

            List<Fornecedor> lista = fdao.List();

            foreach (var forn in lista)
            {
                dgvForn.Rows.Add(forn.Id, forn.Nome, forn.RazaoSocial, forn.CNPJ, forn.Ativo, forn.AtividadeEconomica, forn.Telefone, forn.Email);
            }
        }
    }
}
